<header class="navbar">
	  <section class="navbar-section">
		<a href="about-us.php" class="btn btn-link">About Us</a>
		<a href="admissions.php" class="btn btn-link">Admissions</a>
		<a href="services.php" class="btn btn-link">Services</a>
	  </section>
	  <section class="navbar-center">
		<a href="index.php"><img src="img/logo.png" style="max-width:128px;"></a>
	  </section>
	  <section class="navbar-section">
		<a href="program.php" class="btn btn-link">Program</a>
		<a href="contact-us.php" class="btn btn-link">Contact Us</a>
	  </section>
</header>	