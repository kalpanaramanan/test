<footer class="text-center">
		&copy; <?php echo date("Y"); ?> Lambton College <br>
	</footer>